"use client"

import { ChevronRight } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface ModuleCardProps {
  name: string
  number: string
  difficulty?: "Easy" | "Medium" | "Hard"
  isLoading?: boolean
}

export function ModuleCard({ name, number, difficulty, isLoading }: ModuleCardProps) {
  if (isLoading) {
    return <ModuleCardSkeleton />
  }

  const difficultyDot = {
    Easy: "bg-green-500",
    Medium: "bg-amber-500",
    Hard: "bg-red-500",
  }

  return (
    <Card className="group border-border/50 bg-card hover:border-border hover:shadow-md transition-all duration-200 cursor-pointer">
      <CardContent className="p-5">
        <div className="flex items-center justify-between">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <p className="text-sm font-mono text-muted-foreground">{number}</p>
              {difficulty && (
                <span className={`w-2 h-2 rounded-full ${difficultyDot[difficulty]}`} />
              )}
            </div>
            <h3 className="text-base font-medium text-foreground group-hover:text-primary transition-colors truncate">
              {name}
            </h3>
          </div>
          <ChevronRight className="h-4 w-4 text-muted-foreground/50 group-hover:text-primary group-hover:translate-x-0.5 transition-all flex-shrink-0 ml-3" />
        </div>
      </CardContent>
    </Card>
  )
}

export function ModuleCardSkeleton() {
  return (
    <Card className="border-border/50 bg-card">
      <CardContent className="p-5">
        <div className="flex items-center justify-between">
          <div className="flex-1 min-w-0">
            <div className="h-4 w-16 bg-muted rounded animate-pulse mb-2" />
            <div className="h-5 w-36 bg-muted rounded animate-pulse" />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
