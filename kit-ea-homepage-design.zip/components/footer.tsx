import Link from "next/link"
import { Coffee } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t border-border/40 mt-8">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <Link href="/" className="flex items-center gap-2">
            <Coffee className="h-4 w-4 text-secondary" />
            <span className="text-sm font-medium">
              <span className="text-primary">KI</span>
              <span className="text-secondary">Tea</span>
            </span>
          </Link>
          
          <p className="text-xs text-muted-foreground text-center">
            Made by students, for students. Not affiliated with KIT.
          </p>
        </div>
      </div>
    </footer>
  )
}
