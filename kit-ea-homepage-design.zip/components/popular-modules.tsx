"use client"

import { useEffect, useState } from "react"
import { ModuleCard, ModuleCardSkeleton } from "./module-card"

const recentModules = [
  { name: "Linear Algebra I", number: "MA-101", difficulty: "Medium" as const },
  { name: "Programming Fundamentals", number: "CS-100", difficulty: "Easy" as const },
  { name: "Analysis I", number: "MA-102", difficulty: "Hard" as const },
  { name: "Physics for Engineers", number: "PH-201", difficulty: "Medium" as const },
  { name: "Data Structures", number: "CS-201", difficulty: "Medium" as const },
  { name: "Probability Theory", number: "MA-301", difficulty: "Hard" as const },
]

export function PopularModules() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 600)
    return () => clearTimeout(timer)
  }, [])

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-6">
          Recently reviewed
        </h2>

        <div className="grid grid-cols-1 gap-3">
          {isLoading
            ? [...Array(6)].map((_, i) => <ModuleCardSkeleton key={i} />)
            : recentModules.map((module) => (
                <ModuleCard key={module.number} {...module} />
              ))
          }
        </div>
      </div>
    </section>
  )
}
