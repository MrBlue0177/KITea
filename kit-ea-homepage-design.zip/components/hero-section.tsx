"use client"

import { useState } from "react"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"

export function HeroSection() {
  const [searchFocused, setSearchFocused] = useState(false)
  const [searchValue, setSearchValue] = useState("")

  return (
    <section className="relative min-h-[60vh] flex items-center justify-center pt-24 pb-16">
      <div className="relative max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Main heading */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-semibold tracking-tight mb-4 text-balance">
          <span className="text-foreground">Get the </span>
          <span className="text-secondary">Tea</span>
          <span className="text-foreground"> on </span>
          <span className="text-primary">KIT</span>
          <span className="text-foreground"> modules</span>
        </h1>

        {/* Subtitle */}
        <p className="text-lg text-muted-foreground max-w-md mx-auto mb-10 text-pretty">
          Honest reviews from students, for students.
        </p>

        {/* Search bar */}
        <div className="relative max-w-xl mx-auto">
          <div
            className={`
              relative rounded-2xl transition-all duration-200 ease-out
              ${searchFocused 
                ? "shadow-lg shadow-primary/10" 
                : "shadow-md hover:shadow-lg"
              }
            `}
          >
            <div className="relative flex items-center bg-card rounded-2xl border border-border overflow-hidden">
              <Search className={`
                absolute left-4 h-5 w-5 transition-colors duration-200
                ${searchFocused ? "text-primary" : "text-muted-foreground"}
              `} />
              <Input
                type="text"
                placeholder="Search by module name or number..."
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                onBlur={() => setSearchFocused(false)}
                className="
                  w-full py-5 pl-12 pr-4 text-base 
                  border-0 bg-transparent 
                  focus-visible:ring-0 focus-visible:ring-offset-0
                  placeholder:text-muted-foreground/50
                "
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
