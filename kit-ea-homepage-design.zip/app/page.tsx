import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { PopularModules } from "@/components/popular-modules"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <HeroSection />
      <PopularModules />
      <Footer />
    </main>
  )
}
